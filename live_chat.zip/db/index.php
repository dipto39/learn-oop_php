<?php
header("Location: http://localhost:890/new%20exersice/exersise/live_chat/index.php");    

?>
<?php
session_start();
session_unset();
session_destroy();
echo '<script>window.location.replace("http://localhost:890/new%20exersice/exersise/live_chat/");</script>';

 ?>
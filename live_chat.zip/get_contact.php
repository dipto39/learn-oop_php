<?php
include "db/database.php";
$db=new database();
// $db->select('users',"*",null," uid=40 AND TIMESTAMPDIFF(MINUTE, status, NOW()) < 1",null,null);

// $res=$db->show_result();
// echo count($res[0]);

session_start();
                    $ctable="C".$_SESSION['fname'].$_SESSION['uid'];
                    $ctable = str_replace(' ', '', $ctable);
                    $db->select($ctable,"*",null,null,null,null);
                    $res1=$db->show_result();
                    //$bal="";
                    if(count($res1[0]) > 0){
                        $data="";
                        foreach($res1[0] as list("cid"=>$cid,"uid"=>$uid,"up"=>$up,"fname"=>$fname,"lsms"=>$lsms)){
                          if(strlen($lsms) > 22){
                            $lsm=substr($lsms, 0, 19)."..." ;
                            $lsms= $lsm;
                          }else{
                            $lsms= $lsms;
                          }
                                    $data.='<div class="contact" data-attr="'.$uid.'">
                                    <img src="admin/up/'.$up.'" alt="">
                                    <div class="contact_name">
                                        <h3 class="cfname">'.$fname.'</h3>
                                        <p>'.$lsms.'</p>
                                    </div>
                                    <div class="contact_time ">';
                                        $db->select('users',"*",null," uid=$uid AND TIMESTAMPDIFF(MINUTE, status, NOW()) < 1",null,null);
                                        $res2=$db->show_result();
                                        if(count($res2[0]) > 0){
                                       $data.="<p style='color:green'>Online</p>";
                                      }else{
                                       $data.="<p style='color:red'>Ofline</p>";
                                        

                                            
                                           
                                       }
                                  $data.= ' </div>
                                </div>';
                        }
                      echo $data;
                    }else{
                        echo '<div class="nothing">
                        <h2>No contacts found...please search with user name</h2>
                    </div>';
                    }
                    ?>